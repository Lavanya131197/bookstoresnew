package com.cg.BookStore.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.BookStore.Beans.Book;

@Repository("bookDao")
public class BookDaoImpl implements BookDao {

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public boolean saveBook(Book book) {
		entityManager.persist(book);
		Book newBook = entityManager.find(Book.class, book.getId());
		if (newBook != null) {
			return true;
		}
		return false;

	}

	public List<Book> listBooks() {

		Query q = entityManager.createQuery("from Book");
		List<Book> list = q.getResultList();
		return list;
	}

	public Book getBook(Long id) {
		Book b = entityManager.find(Book.class, id);
		return b;
	}

	public boolean deleteBook(Long id) {

		Book boo = entityManager.find(Book.class, id);
		entityManager.remove(boo);
		return true;
	}

	@Transactional
	@Override
	public boolean update(Book book) {

		entityManager.merge(book);
		return true;

	}

}
