package com.cg.BookStore.Service;

import java.util.List;

import com.cg.BookStore.Beans.Book;



public interface BookService {

	/*
	 * CREATING AND UPDATING BOOT DATA
	 */
	public void saveBook(Book book);
    public void update(Book book);
	/*
	 * READING BOOK DATA
	 */  
	public List<Book> listBooks();
	public Book getBook(Long id);

	/*
	 * DELETING BOOK
	 */
	public void deleteBook(Long id);

}
